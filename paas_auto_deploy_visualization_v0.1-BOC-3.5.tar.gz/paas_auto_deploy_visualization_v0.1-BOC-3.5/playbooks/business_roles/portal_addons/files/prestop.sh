#!/bin/bash
curl -H 'Content-Type:application/json' -XGET ${APP_HOST}:${APP_PORT}/job/terminate_all_running_jobs.json

