### boc增加支持arm环境
1. 业务集群支持arm节点,包括部署,增删节点
2. portal集群支持arm节点, 包括部署,增删节点
3. k8s组件支持arm节点
   1. efk组件仅在纯arm集群环境部署7.13.1版本, 其他场景部署7.5.1版本, efk7.5.1版本不支持arm
   2. gpu相关组件不支持arm节点
4. portal组件支持arm节点
5. 部分镜像更新
   1. keepalived
   2. mysql-client
   3. mysqldump
   4. registry
   5. worker
   6. mariadb
6. 部署引导工具支持Kylin v10 arm64环境
   1. 增加bocctl-KylinV10-arm64
   2. 跟新bocctl打包方式, 执行命令不变
### boc平台整合mesh
1. 增加mesh相关组件部署逻辑
   1. bocloud-component
   2. jaeger
   3. paas-mesh
   4. rabbitmq
2. 增加创建mq用户和密码的task
3. 增加跟新cm中token的task
4. 增加和mesh相关的nfs共享文件
5. 配置文件中增加mesh相关字段, 允许在config.yaml设置是否部署mesh
   1. 在配置文件中设置mesh.enable 为false, 可通过yaml文件创建mesh组件

新增对boc3.4平滑升级至boc3.5
1. 更新kubelet和apiserver 1.21.1版本配置
2. 更新k8s组件kube_proxy, prometheus, logrotate ,efk, beyondac, kube_security, beyondlet, kube_kubectl ,plumber,carina
3. 更新portal组件和paas_clair postgresql服务